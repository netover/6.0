"""Monitoring and observability routes."""

from .dashboard import router as monitoring_dashboard_router

__all__ = ["monitoring_dashboard_router"]
