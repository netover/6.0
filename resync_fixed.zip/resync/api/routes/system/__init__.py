"""System configuration routes."""
