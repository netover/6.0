"""
DEPRECATED: This module has been moved.
"""

raise ImportError(
    "resync.core.audit_to_kg_pipeline has been moved and refactored to "
    "resync.core.continual_learning.audit_to_kg_pipeline. "
    "The API has changed (AuditFinding -> AuditResult, etc.). "
    "Please update your imports and code."
)
