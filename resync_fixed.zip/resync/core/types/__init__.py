"""Typed helpers for core modules."""
